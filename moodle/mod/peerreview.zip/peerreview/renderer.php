<?php

$PAGE->requires->css(new moodle_url('style.css'));